import requests

url = 'https://charmerapi.herokuapp.com/api/topic'
payload = {'tweet': 'count'}

print(payload)

client_id: "-KfbxwzUfetX14BLgD59"
client_secret: "QpCWwwXdpsLCfsGt44Sz2CLtW5ud2Rnv"
grant_type: "client_credentials"
scope: "charm.read profile.read profile.write user.write topic.read topic.write"

r = requests.post('https://charmerapi.herokuapp.com/api/topic', data = payload)

print(payload)
